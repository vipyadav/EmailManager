﻿using System.ComponentModel;

namespace DeveloperTest.Models
{
    public enum Encryptions
    {
        [Description("Unencrypted")]
        Unencrypted,

        [Description("SSL/TLS")]
        SSL_TLS,

        [Description("STARTTLS")]
        STARTTLS
    }
}
