﻿namespace DeveloperTest.Common
{
    public static class Constants
    {
        public const int MaxServerConnectionOrParallelThreads = 5;
    }
}
