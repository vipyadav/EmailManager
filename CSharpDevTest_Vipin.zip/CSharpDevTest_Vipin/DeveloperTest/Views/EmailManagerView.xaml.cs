﻿using System.Windows;

namespace DeveloperTest.Views
{
    /// <summary>
    /// Interaction logic for EmailManagerView.xaml
    /// </summary>
    public partial class EmailManagerView : Window
    {
        public EmailManagerView()
        {
            InitializeComponent();       
        }
    }
}
