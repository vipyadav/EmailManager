﻿using DeveloperTest.Services;

namespace DeveloperTest.Contracts
{
    public interface IEmailServiceFactory
    {
        IEmailService GetInstance(IConnection connection);
    }
}
