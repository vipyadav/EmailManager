﻿using DeveloperTest.Models;
using System.Threading.Tasks;

namespace DeveloperTest.Contracts
{
    public interface IConnection
    {
        ServerTypes ConnectionType { get; set; }
        Task<object> GetInstance<T>();
        object GetInstance();
        Task DisposeInstance(object instance);
    }
}
