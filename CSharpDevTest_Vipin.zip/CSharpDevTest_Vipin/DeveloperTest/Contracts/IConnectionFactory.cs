﻿using DeveloperTest.Models;

namespace DeveloperTest.Contracts
{
    public interface IConnectionFactory
    {
        IConnection GetInstance(Connection connectionInfo);
    }
}
