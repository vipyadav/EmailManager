﻿using DeveloperTest.Connections;
using DeveloperTest.Contracts;
using DeveloperTest.Models;

namespace DeveloperTest.Factory
{
    public class ConnectionFactory : IConnectionFactory
    {
        public IConnection GetInstance(Connection connectionInfo)
        {
            IConnection connection = null;

            switch (connectionInfo.ServerType)
            {
                case ServerTypes.IMAP:
                    connection =  new ImapConnection(connectionInfo);
                    break;
                case ServerTypes.POP3:
                    connection = new Pop3Connection(connectionInfo);
                    break;
            }

            return connection;
        }
    }
}
